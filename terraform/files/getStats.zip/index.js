/**
 * StaySafe.my.id — getStats Cloud Run Function
 * GET /api/reports/stats
 * Aggregates crime incident reports into spatial grid cells for heatmap visualization.
 */

const { getDb } = require('./db');

exports.getStats = async (req, res) => {
  // Enable CORS
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') {
    res.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.set('Access-Control-Max-Age', '3600');
    return res.status(204).send('');
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const db = await getDb();
    const reportsCollection = db.collection('reports');

    // Aggregate statistics for the last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Advanced geospatial grouping pipeline:
    // 1. Filter reports from last 30 days
    // 2. Round coordinates to 3 decimals (approx. 110m grid cell size)
    // 3. Group by grid cell & category to count category frequencies
    // 4. Sort descending within grid cells to prepare majority voting
    // 5. Group by grid cell, pushing all categories and summing counts
    // 6. Project output: pick top category (index 0) and total count
    const pipeline = [
      {
        $match: {
          createdAt: { $gte: thirtyDaysAgo }
        }
      },
      {
        $project: {
          category: 1,
          lng: { $arrayElemAt: ['$location.coordinates', 0] },
          lat: { $arrayElemAt: ['$location.coordinates', 1] }
        }
      },
      {
        $project: {
          category: 1,
          gridLng: { $round: ['$lng', 3] },
          gridLat: { $round: ['$lat', 3] }
        }
      },
      {
        $group: {
          _id: {
            lng: '$gridLng',
            lat: '$gridLat',
            category: '$category'
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: {
          '_id.lng': 1,
          '_id.lat': 1,
          count: -1
        }
      },
      {
        $group: {
          _id: {
            lng: '$_id.lng',
            lat: '$_id.lat'
          },
          categories: {
            $push: {
              category: '$_id.category',
              count: '$count'
            }
          },
          totalCount: { $sum: '$count' }
        }
      },
      {
        $project: {
          _id: 0,
          lng: '$_id.lng',
          lat: '$_id.lat',
          count: '$totalCount',
          category: { $arrayElemAt: ['$categories.category', 0] }
        }
      }
    ];

    const stats = await reportsCollection.aggregate(pipeline).toArray();

    return res.status(200).json(stats);
  } catch (error) {
    console.error('Error generating stats:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};
