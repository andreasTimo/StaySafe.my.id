/**
 * StaySafe.my.id — postReport Cloud Run Function
 * POST /api/reports
 */

const { getDb } = require('./db');
const { isValidCategory, isValidSubcategory } = require('./categories');

exports.postReport = async (req, res) => {
  // Enable CORS
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') {
    res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.set('Access-Control-Max-Age', '3600');
    return res.status(204).send('');
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const { category, subcategory, description, latitude, longitude } = req.body || {};

    // 1. Mandatory Fields Validation
    if (!category || !subcategory || !description || latitude === undefined || longitude === undefined) {
      return res.status(400).json({ error: 'Semua field wajib diisi.' });
    }

    // 2. Category & Subcategory Validation
    if (!isValidCategory(category)) {
      return res.status(400).json({ error: `Kategori '${category}' tidak valid.` });
    }

    if (!isValidSubcategory(category, subcategory)) {
      return res.status(400).json({ error: `Sub-kategori '${subcategory}' tidak sesuai untuk kategori '${category}'.` });
    }

    // 3. Description Length Validation (max 500 characters)
    if (typeof description !== 'string' || description.trim().length === 0) {
      return res.status(400).json({ error: 'Deskripsi tidak boleh kosong.' });
    }
    if (description.length > 500) {
      return res.status(400).json({ error: 'Deskripsi melebihi batas 500 karakter.' });
    }

    // 4. Geospatial Coordinate Validation (Jabodetabek bounding box check)
    const lat = parseFloat(latitude);
    const lng = parseFloat(longitude);

    if (isNaN(lat) || isNaN(lng)) {
      return res.status(400).json({ error: 'Format koordinat tidak valid.' });
    }

    // Latitude check: must be in Jakarta region (~ -6.5 to -5.5)
    // Longitude check: must be in Jakarta region (~ 106.0 to 107.5)
    if (lat < -8.5 || lat > -5.0 || lng < 105.0 || lng > 108.5) {
      return res.status(400).json({ error: 'Lokasi harus berada di dalam area Jakarta dan sekitarnya.' });
    }

    // 5. Database Insert
    const db = await getDb();
    const reportsCollection = db.collection('reports');

    const newReport = {
      category,
      subcategory,
      description: description.trim(),
      location: {
        type: 'Point',
        coordinates: [lng, lat] // MongoDB expects [longitude, latitude]
      },
      createdAt: new Date()
    };

    const result = await reportsCollection.insertOne(newReport);
    
    // Set internal ID
    newReport._id = result.insertedId;

    // TODO: (Phase 3) Trigger Cloudflare CDN cache purge here if needed

    return res.status(201).json(newReport);
  } catch (error) {
    console.error('Error creating report:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};
