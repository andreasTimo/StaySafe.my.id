/**
 * StaySafe.my.id — getReports Cloud Run Function
 * GET /api/reports
 * Supports geospatial query: sw_lat, sw_lng, ne_lat, ne_lng
 */

const { getDb } = require('./db');

exports.getReports = async (req, res) => {
  // Enable CORS
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') {
    res.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.set('Access-Control-Max-Age', '3600');
    return res.status(204).send('');
  }

  if (req.method !== 'GET') {
    return res.status(451).json({ error: 'Method Not Allowed' });
  }

  try {
    const db = await getDb();
    const reportsCollection = db.collection('reports');

    const { sw_lat, sw_lng, ne_lat, ne_lng } = req.query;
    let query = {};

    if (sw_lat && sw_lng && ne_lat && ne_lng) {
      const swLat = parseFloat(sw_lat);
      const swLng = parseFloat(sw_lng);
      const neLat = parseFloat(ne_lat);
      const neLng = parseFloat(ne_lng);

      if (!isNaN(swLat) && !isNaN(swLng) && !isNaN(neLat) && !isNaN(neLng)) {
        query.location = {
          $geoWithin: {
            $box: [
              [swLng, swLat], // bottom-left [longitude, latitude]
              [neLng, neLat]  // top-right [longitude, latitude]
            ]
          }
        };
      }
    }

    // Default to last 30 days if no bounding box, or combine with it
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    query.createdAt = { $gte: thirtyDaysAgo };

    const reports = await reportsCollection
      .find(query)
      .sort({ createdAt: -1 })
      .limit(500)
      .toArray();

    return res.status(200).json(reports);
  } catch (error) {
    console.error('Error fetching reports:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};
